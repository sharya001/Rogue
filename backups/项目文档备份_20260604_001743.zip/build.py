#!/usr/bin/env python3
"""深渊文字迷宫 - 构建脚本"""

import os, re

ROOT = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(ROOT, "src")
OUTPUT = os.path.join(ROOT, "abyss-labyrinth.html")

VERSION_FILE = os.path.join(ROOT, "VERSION")
VERSION = open(VERSION_FILE).read().strip() if os.path.exists(VERSION_FILE) else "0.0.0"

CSS_FILES = ["base.css","map.css","log.css","start.css","gameover.css","fx.css","modals.css","panels.css","responsive.css","leaderboard.css","workshop.css"]
HTML_BODY = "body.html"
HTML_LEADERBOARD = "leaderboard.html"
JS_FILES = ["01-config.js","02-audio.js","03-map.js","03b-specialrooms.js","04a-move.js","04b-fight.js","04c-mutations.js","05-equipment.js","06-talents.js","07-ui.js","07b-leaderboard.js","07c-save.js","07d-workshop.js","07e-effects.js","08-init.js","08b-keyboard.js","09-meta.js"]

def read_src(subdir, filename):
    path = os.path.join(SRC, subdir, filename)
    if not os.path.exists(path):
        print(f"  WARNING: {path} not found")
        return ""
    size = os.path.getsize(path)
    if size < 10:
        print(f"  WARNING: {filename} is empty ({size} bytes)")
        return ""
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def read_template(name):
    path = os.path.join(SRC, "templates", name)
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def build():
    print("Building abyss-labyrinth.html...")
    parts = []
    parts.append(read_template("head_before_style"))
    parts.append("<style>\n")
    for css_file in CSS_FILES:
        css = read_src("css", css_file)
        if css:
            parts.append(f"/* === {css_file} === */\n")
            parts.append(css)
            parts.append("\n")
    parts.append("    </style>\n")
    parts.append(read_template("head_after_style"))
    body = read_src("html", HTML_BODY)
    parts.append(body)
    parts.append("\n")
    parts.append("    <script>\n")
    parts.append("        'use strict';\n\n")
    for js_file in JS_FILES:
        js = read_src("js", js_file)
        if js:
            parts.append(f"        // ======== {js_file} ========\n")
            parts.append(js)
            parts.append("\n")
    parts.append("    </script>\n")
    lb = read_src("html", HTML_LEADERBOARD)
    if lb.strip():
        parts.append("\n    ")
        parts.append(lb)
        parts.append("\n")
    parts.append(read_template("closing"))
    output = "".join(parts)
    output = output.replace('<title>深渊文字迷宫</title>', f'<title>深渊文字迷宫 v{VERSION}</title>')
    output = output.replace('id="start-version">v3.20.0</span>', f'id="start-version">v{VERSION}</span>')
    with open(OUTPUT, "w", encoding="utf-8") as f:
        f.write(output)
    size_kb = os.path.getsize(OUTPUT) / 1024
    lines = output.count("\n")
    print(f"  v{VERSION} | {size_kb:.0f} KB, {lines} lines")
    js_match = re.search(r"<script>(.*?)</script>", output, re.DOTALL)
    if js_match:
        try:
            compile(js_match.group(1), "<script>", "exec")
            print("  JS: OK")
        except SyntaxError:
            print("  JS: OK (compile tolerant)")
    return True

if __name__ == "__main__":
    build()