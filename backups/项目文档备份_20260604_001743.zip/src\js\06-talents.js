/* ╔══════════════════════════════════════════╗
        ║  MODULE 6: 天赋系统                   ║
        ╚══════════════════════════════════════════╝ */
// ==================== 天赋系统 ====================
        // 获取天赋等级
        function getTalentLevel(talentId) {
                    return gameState.unlockedTalents[talentId] || 0;
                }

                // 根据 talentId 获取天赋名称/描述/图标
                function getTalentInfo(talentId) {
                                    const trees = CONFIG.TALENT_TREES;
                                    for (const treeName of Object.keys(trees)) {
                                        const tree = trees[treeName];
                                        for (const t of (tree.talents || [])) {
                                            if (t.id === talentId) return t;
                                        }
                                    }
                                    return null;
                                }
        
        // 获取某类天赋累积加成
        function getTalentSum(ids) {
            let sum = 0;
            ids.forEach(id => { sum += getTalentLevel(id); });
            return sum;
        }
        
        // 更新侧边栏天赋面板
        function updateTalentPanel() {
            const listEl = document.getElementById('talent-list');
            const pointsEl = document.getElementById('talent-points-display');
            if (!listEl || !pointsEl) return;
            
            pointsEl.textContent = `可用天赋点: ${gameState.talentPoints}`;
            pointsEl.style.color = gameState.talentPoints > 0 ? '#ff0' : '#666';
            
            let html = '';
            const talents = gameState.unlockedTalents;
            for (const [id, lv] of Object.entries(talents)) {
                if (lv <= 0) continue;
                // 找到天赋信息
                let info = null;
                for (const tree of Object.values(CONFIG.TALENT_TREES)) {
                    const found = tree.talents.find(t => t.id === id);
                    if (found) { info = found; break; }
                }
                if (!info) continue;
                const lvClass = lv >= 3 ? 'lv3' : (lv >= 2 ? 'lv2' : '');
                html += `<span class="talent-badge ${lvClass}">${info.icon}${info.name}${lv > 1 ? ' Lv'+lv : ''}</span>`;
            }
            listEl.innerHTML = html || '<span style="color:#555;font-size:11px;">暂无天赋</span>';
            
            updateSkillButton();
        }
        
        // 更新主动技能按钮
        function updateSkillButton() {
            const btn = document.getElementById('skill-btn');
            if (!btn) return;
            
            // 查找主动技能
            let activeTalent = null;
            for (const tree of Object.values(CONFIG.TALENT_TREES)) {
                const found = tree.talents.find(t => t.active && getTalentLevel(t.id) > 0);
                if (found) { activeTalent = found; break; }
            }
            
            if (!activeTalent) {
                btn.textContent = '🔒 未学习技能';
                btn.className = 'skill-btn cooldown';
                return;
            }
            
            if (gameState.skillActive && gameState.skillTurns > 0) {
                btn.textContent = `${activeTalent.icon} ${activeTalent.name} (剩余${gameState.skillTurns}回合)`;
                btn.className = 'skill-btn active';
            } else if (gameState.skillCooldown > 0) {
                btn.textContent = `${activeTalent.icon} ${activeTalent.name} (冷却${gameState.skillCooldown}层)`;
                btn.className = 'skill-btn cooldown';
            } else {
                btn.textContent = `${activeTalent.icon} ${activeTalent.name} [Q]`;
                btn.className = 'skill-btn ready';
            }
        }
        
        // 使用主动技能
        function useActiveSkill() {
            if (gameState.isGameOver) return;
            if (gameState.skillCooldown > 0 || gameState.skillActive) return;
            
            // 查找主动技能
            let activeTalent = null;
            for (const tree of Object.values(CONFIG.TALENT_TREES)) {
                const found = tree.talents.find(t => t.active && getTalentLevel(t.id) > 0);
                if (found) { activeTalent = found; break; }
            }
            if (!activeTalent) return;
            
            const talentId = activeTalent.id;
            
            if (talentId === 'e6') {
                // 探知：揭示3×3范围
                gameState.skillActive = true;
                gameState.skillTurns = 1; // 一次性效果
                gameState.skillCooldown = activeTalent.cooldown;
                addLog(`👁️ 探知发动！揭示周围区域`, 'log-system');
                sfx.play('floor');
                sfx.play('floor');
                                revealArea();
                            } else if (talentId === 's6') {
                                gameState.skillActive = true;
                                gameState.skillTurns = 3;
                                gameState.skillCooldown = activeTalent.cooldown;
                                addLog(`✨ 圣盾发动！3回合内免疫伤害`, 'log-gain');
                                sfx.play('boss_kill');
                            }
            
                            gameState.achievementStats.skillUses++;
                            checkAchievements();
            
            updateSkillButton();
            updateStatusBar();
        }
        
        // 探知：揭示周围3×3（去除迷雾/显示隐藏信息）
        function revealArea() {
            const p = gameState.player;
            addLog(`👁️ 探知：位置 (${p.x},${p.y}) 周围区域已扫描`, 'log-system');
            // 在日志中显示周围信息
            let nearby = [];
            for (let dy = -1; dy <= 1; dy++) {
                for (let dx = -1; dx <= 1; dx++) {
                    const nx = p.x + dx, ny = p.y + dy;
                    if (nx < 0 || ny < 0 || nx >= CONFIG.MAP_WIDTH || ny >= CONFIG.MAP_HEIGHT) continue;
                    const cell = gameState.map[ny][nx];
                    if (cell === '#') continue;
                    // Boss 层未击败 Boss 时隐藏出口
                    if (gameState.isBossFloor && !gameState.bossDefeated) continue;
                    if (Math.abs(nx - gameState.exit.x) <= 1 && Math.abs(ny - gameState.exit.y) <= 1) nearby.push('🚪出口方向');
                }
            }
            if (nearby.length > 0) addLog(`👁️ ${nearby[0]}`, 'log-gain');
        }
        
        // 每回合/战斗结束后减少主动技能回合
        function tickSkillTurns() {
            if (gameState.skillActive && gameState.skillTurns > 0) {
                gameState.skillTurns--;
                if (gameState.skillTurns <= 0) {
                    gameState.skillActive = false;
                    addLog(`主动技能效果结束，进入冷却`, 'log-system');
                }
                updateSkillButton();
            }
        }
        
        // 每层减少冷却
        function tickSkillCooldown() {
                    if (gameState.skillCooldown > 0) {
                        // 魔力紊乱：冷却消耗翻倍
                        const ticks = gameState.envEffect && gameState.envEffect.id === 'magicChaos' ? 2 : 1;
                        gameState.skillCooldown = Math.max(0, gameState.skillCooldown - ticks);
                        if (gameState.skillCooldown <= 0) {
                            addLog(`⚡ 主动技能冷却完毕！`, 'log-system');
                        }
                        updateSkillButton();
                    }
                }
        
        // 打开天赋选择弹窗
        function openTalentModal() {
            if (gameState.talentPoints <= 0) return;
            
            const modal = document.getElementById('talent-modal');
            const subtitle = document.getElementById('talent-modal-subtitle');
            const container = document.getElementById('talent-trees-container');
            
            subtitle.textContent = `剩余天赋点: ${gameState.talentPoints}`;
            
            let html = '';
            for (const [treeKey, tree] of Object.entries(CONFIG.TALENT_TREES)) {
                html += `<div class="talent-tree-group">`;
                html += `<div class="talent-tree-header" style="color:${tree.color}">${tree.icon} ${tree.name}</div>`;
                html += `<div class="talent-grid">`;
                
                tree.talents.forEach(talent => {
                    const currentLv = getTalentLevel(talent.id);
                    const isMaxed = currentLv >= talent.maxLevel;
                    const cls = isMaxed ? 'maxed' : '';
                    html += `<div class="talent-item ${cls}" onclick="${isMaxed ? '' : `learnTalent('${treeKey}','${talent.id}')`}">`;
                    html += `<span class="talent-item-icon">${talent.icon}</span>`;
                    html += `<span class="talent-item-name">${talent.name}</span>`;
                    html += `<span class="talent-item-level">Lv${currentLv}/${talent.maxLevel}</span>`;
                    html += `<span class="talent-item-desc">${talent.desc}${talent.active ? ' [主动]' : ''}</span>`;
                    html += `</div>`;
                });
                
                html += `</div></div>`;
            }
            
            container.innerHTML = html;
            modal.style.display = 'flex';
            gameState.shopOpen = true;  // 复用 shopOpen 标志锁定键盘输入
        }
        
        // 关闭天赋弹窗
function closeTalentModal() {
            document.getElementById('talent-modal').style.display = 'none';
            gameState.shopOpen = false;
        }

function learnTalent(treeKey, talentId) {
            if (gameState.talentPoints <= 0) return;
            
            const tree = CONFIG.TALENT_TREES[treeKey];
            if (!tree) return;
            const talent = tree.talents.find(t => t.id === talentId);
            if (!talent) return;
            
            const currentLv = getTalentLevel(talentId);
            if (currentLv >= talent.maxLevel) return;
            
            // 消耗天赋点
            gameState.talentPoints--;
            gameState.unlockedTalents[talentId] = currentLv + 1;
            
            const newLv = getTalentLevel(talentId);
            addLog(`⭐ 学习天赋：${talent.icon} ${talent.name} Lv${newLv}`, 'log-gain');
            sfx.play('levelup');
            
            // 应用天赋效果
            applyTalentEffect(talentId, treeKey);
            
            // 刷新弹窗
            if (gameState.talentPoints > 0) {
                openTalentModal();
            } else {
                closeTalentModal();
            }
            
            updateTalentPanel();
            updateStatusBar();
        }

function applyTalentEffect(talentId, treeKey) {
            const p = gameState.player;
            const lv = getTalentLevel(talentId);
            
            switch (talentId) {
                case 'c2': p.atk += 3; break;           // 重击
                case 'c3': p.def += 3; break;           // 铁壁
                case 's1': p.maxHp += 15; p.hp += 15; break; // 坚韧
            }
        }

function checkTalentUnlock(newLevel) {
            if (newLevel > 0 && newLevel % CONFIG.TALENT_PER_LEVEL === 0) {
                gameState.talentPoints++;
                addLog(`⭐ 获得天赋点！(Lv${newLevel}) 当前 ${gameState.talentPoints} 点`, 'log-gain');
                updateTalentPanel();
                // 延迟弹出选择界面
                setTimeout(() => openTalentModal(), 500);
            }
        }
