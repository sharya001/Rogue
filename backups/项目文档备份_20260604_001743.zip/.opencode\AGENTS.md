# 深渊文字迷宫 — AI 助手开发规则

## 项目信息
- **项目**: 深渊文字迷宫 (Abyss Text Labyrinth)
- **路径**: `C:\Users\Shary\Desktop\hermes\Rogue`
- **类型**: HTML5 文字迷宫 Roguelike 游戏
- **开发者**: 傻妞
- **架构**: `src/` 源文件 → `python build.py` → `abyss-labyrinth.html`

## 每次代码改动后的必做清单

以下步骤每次代码改动后必须**全自动执行**，不得遗漏：

1. **更新 `VERSION`** — 版本号推进（Bug修复 +0.0.1，新功能 +0.1.0，重大重构 +1.0.0）
2. **更新 `CHANGELOG.md`** — 新版本章节，按类别（🐛修复 / ✨新功能 / 🎮机制）记录所有改动
3. **更新 `README.md`** — 底部版本号 + 修改历史表新增一行
4. **更新 `DEVELOPMENT.md`** — 底部版本号
5. **更新 `GUIDE.md`** — 顶部日期 + 版本号
6. **运行 `python build.py`** — 构建产物
7. **打包分发版** — 压缩 `abyss-labyrinth.html` + `README.md` + `GUIDE.md` 到 `dist/深渊文字迷宫_v{版本号}_{YYYYMMDD_HHmmss}.zip`
8. **备份到 `backups/`** — 复制 `abyss-labyrinth.html` + 4份文档，命名 `{文件名}_v{版本号}_{YYYYMMDD_HHMMSS}.{扩展名}`

## 分发打包（每次构建后自动执行）
```powershell
$v = (Get-Content VERSION).Trim(); $ts = Get-Date -Format "yyyyMMdd_HHmmss"
if (-not (Test-Path "dist")) { New-Item -ItemType Directory -Path "dist" -Force }
Compress-Archive -Path "abyss-labyrinth.html","README.md","GUIDE.md" -DestinationPath "dist/深渊文字迷宫_v${v}_${ts}.zip" -Force
```
分发包包含：游戏HTML + 项目说明 + 玩家指南，不含源码/临时文件/备份。

## 代码规范要点

- **gameState 两处声明**: 新字段必须在 `let gameState = {...}`（`01-config.js`）和 `restartGame()`（`07-ui.js`）两处都初始化
- **存档兼容**: 新字段也需在 `continueGame()`（`07c-save.js`）的默认初始化和恢复逻辑中处理
- **构建前检查**: `python build.py` 自带 JS 语法验证
- **三层战斗代码**: Boss/手动/自动 三段平行代码，改动涉及攻击/防御/死亡逻辑时需全部同步
- **弹窗回调异步**: `showEquipCompare` 和 `showLevelUpModal` 异步，后续逻辑必须放在回调内

## 开发文档位置
- `DEVELOPMENT.md` — 完整开发规范、架构、常见陷阱
- `README.md` — 项目说明、游戏特性、修改历史
- `CHANGELOG.md` — 版本更新日志
- `GUIDE.md` — 玩家指南
- `temp/Phase4_企划.txt` — Phase 4 内容深挖企划