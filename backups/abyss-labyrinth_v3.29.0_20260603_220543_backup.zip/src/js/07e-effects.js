// ======== 特效与辅助 ========

                function drawCastleBg() {
                            const canvas = document.getElementById('start-castle-bg');
                            if (!canvas) return;
                            canvas.width = canvas.offsetWidth || window.innerWidth;
                            canvas.height = canvas.offsetHeight || window.innerHeight;
                            const ctx = canvas.getContext('2d');
                            const W = canvas.width, H = canvas.height;
                            ctx.clearRect(0, 0, W, H);

                            const groundY = H * 0.58;  // 地平线上移，给城堡更多空间
                            const cx = W * 0.5;
                            const castleW = W * 0.55;  // 更宽
                            const castleH = H * 0.42;

                            // === 远山背景 ===
                            ctx.fillStyle = '#060210';
                            ctx.beginPath();
                            ctx.moveTo(0, groundY);
                            ctx.quadraticCurveTo(W*0.2, groundY-H*0.08, W*0.35, groundY-H*0.05);
                            ctx.quadraticCurveTo(W*0.5, groundY-H*0.12, W*0.65, groundY-H*0.05);
                            ctx.quadraticCurveTo(W*0.8, groundY-H*0.08, W, groundY);
                            ctx.fill();

                            // === 远景小塔楼（剪影，更暗） ===
                            const bgTowers = [
                                { x: cx - castleW*0.35, w: castleW*0.04, h: castleH*0.3 },
                                { x: cx - castleW*0.15, w: castleW*0.05, h: castleH*0.4 },
                                { x: cx + castleW*0.25, w: castleW*0.04, h: castleH*0.35 },
                                { x: cx + castleW*0.35, w: castleW*0.05, h: castleH*0.28 },
                            ];
                            ctx.fillStyle = '#080418';
                            bgTowers.forEach(t => {
                                ctx.fillRect(t.x, groundY - t.h, t.w, t.h);
                                // 尖顶
                                ctx.beginPath();
                                ctx.moveTo(t.x - t.w*0.2, groundY - t.h);
                                ctx.lineTo(t.x + t.w/2, groundY - t.h - castleH*0.08);
                                ctx.lineTo(t.x + t.w*1.2, groundY - t.h);
                                ctx.fill();
                            });

                            // === 主城堡基座 ===
                            ctx.fillStyle = '#0a0018';
                            ctx.fillRect(cx - castleW*0.42, groundY - castleH*0.02, castleW*0.84, castleH*0.04);

                            // === 正面7座塔楼 ===
                            const mainTowers = [
                                { x: cx - castleW*0.4,  w: castleW*0.07, h: castleH*0.55, spire:true },
                                { x: cx - castleW*0.25, w: castleW*0.09, h: castleH*0.7,  spire:true },
                                { x: cx - castleW*0.1,  w: castleW*0.13, h: castleH*0.85, spire:true, keep:true },
                                { x: cx + castleW*0.06, w: castleW*0.13, h: castleH*0.9,  spire:true, keep:true },
                                { x: cx + castleW*0.22, w: castleW*0.09, h: castleH*0.65, spire:true },
                                { x: cx + castleW*0.35, w: castleW*0.07, h: castleH*0.5,  spire:true },
                                { x: cx + castleW*0.43, w: castleW*0.06, h: castleH*0.4,  spire:true },
                            ];

                            mainTowers.forEach(t => {
                                const tx = t.x, th = t.h;
                                // 塔身（渐变增加立体感）
                                const grad = ctx.createLinearGradient(tx, 0, tx + t.w, 0);
                                grad.addColorStop(0, '#0d0020');
                                grad.addColorStop(0.3, '#120028');
                                grad.addColorStop(0.7, '#0d0020');
                                grad.addColorStop(1, '#080015');
                                ctx.fillStyle = grad;
                                ctx.fillRect(tx, groundY - th, t.w, th);

                                // 城垛
                                const bw = t.w / (t.w > castleW*0.1 ? 4 : 3);
                                const count = t.w > castleW*0.1 ? 4 : 3;
                                ctx.fillStyle = '#0d0020';
                                for (let b = 0; b < count; b++) {
                                    ctx.fillRect(tx + b*bw + bw*0.1, groundY - th - H*0.018, bw*0.8, H*0.022);
                                }

                                // 尖顶
                                if (t.spire) {
                                    const spireGrad = ctx.createLinearGradient(tx, 0, tx + t.w, 0);
                                    spireGrad.addColorStop(0, '#150830');
                                    spireGrad.addColorStop(0.5, '#1a0a40');
                                    spireGrad.addColorStop(1, '#100620');
                                    ctx.fillStyle = spireGrad;
                                    ctx.beginPath();
                                    ctx.moveTo(tx - t.w*0.15, groundY - th);
                                    ctx.lineTo(tx + t.w/2, groundY - th - castleH*0.12);
                                    ctx.lineTo(tx + t.w*1.15, groundY - th);
                                    ctx.closePath();
                                    ctx.fill();
                                    // 尖顶上的小旗
                                    if (t.keep) {
                                        ctx.fillStyle = '#200840';
                                        ctx.fillRect(tx + t.w/2 - 1, groundY - th - castleH*0.14, 2, castleH*0.025);
                                        ctx.fillStyle = '#301060';
                                        ctx.beginPath();
                                        ctx.moveTo(tx + t.w/2, groundY - th - castleH*0.14);
                                        ctx.lineTo(tx + t.w/2 + castleW*0.02, groundY - th - castleH*0.11);
                                        ctx.lineTo(tx + t.w/2, groundY - th - castleH*0.08);
                                        ctx.fill();
                                    }
                                }

                                // 窗户（多层次发光）
                                const wy = groundY - th * (t.keep ? 0.35 : 0.45);
                                const ww = t.w * (t.keep ? 0.15 : 0.22);
                                const wh = H * (t.keep ? 0.03 : 0.02);
                                // 外光晕
                                const glow = ctx.createRadialGradient(tx+t.w/2, wy+wh/2, 0, tx+t.w/2, wy+wh/2, ww*2);
                                glow.addColorStop(0, 'rgba(255,180,40,0.25)');
                                glow.addColorStop(0.5, 'rgba(255,140,20,0.06)');
                                glow.addColorStop(1, 'rgba(0,0,0,0)');
                                ctx.fillStyle = glow;
                                ctx.fillRect(tx - ww, wy - wh, ww*3, wh*3);
                                // 窗户本体
                                ctx.fillStyle = 'rgba(255,200,60,0.3)';
                                ctx.fillRect(tx + t.w*0.3, wy, ww, wh);
                            });

                            // === 城墙（锯齿状垛口） ===
                            ctx.fillStyle = '#0a0018';
                            const wallY = groundY - castleH*0.38;
                            ctx.fillRect(cx - castleW*0.38, wallY, castleW*0.8, H*0.012);
                            // 垛口
                            for (let bx = cx - castleW*0.36; bx < cx + castleW*0.4; bx += castleW*0.04) {
                                ctx.fillRect(bx, wallY - H*0.012, castleW*0.025, H*0.014);
                            }

                            // === 城门拱 ===
                            const gateW = castleW*0.08, gateH = castleH*0.2;
                            const gateX = cx - gateW/2, gateY = groundY - gateH;
                            // 门框
                            ctx.fillStyle = '#150830';
                            ctx.fillRect(gateX - castleW*0.01, gateY - H*0.01, gateW + castleW*0.02, gateH + H*0.01);
                            // 门洞
                            ctx.fillStyle = '#020008';
                            ctx.fillRect(gateX, gateY, gateW, gateH);
                            // 拱形顶部
                            ctx.beginPath();
                            ctx.arc(cx, gateY, gateW/2, Math.PI, 0);
                            ctx.fill();
                            // 吊闸（铁栅栏纹理）
                            ctx.strokeStyle = '#150820';
                            ctx.lineWidth = 1;
                            for (let gy = gateY; gy < gateY + gateH*0.6; gy += H*0.012) {
                                ctx.beginPath();
                                ctx.moveTo(gateX, gy);
                                ctx.lineTo(gateX + gateW, gy);
                                ctx.stroke();
                            }

                            // === 地面 ===
                            const groundGrad = ctx.createLinearGradient(0, groundY, 0, H);
                            groundGrad.addColorStop(0, '#080012');
                            groundGrad.addColorStop(0.15, '#0a0018');
                            groundGrad.addColorStop(0.5, '#050010');
                            groundGrad.addColorStop(1, '#020008');
                            ctx.fillStyle = groundGrad;
                            ctx.fillRect(0, groundY, W, H - groundY);

                            // === 多层雾（深度感） ===
                            for (let layer = 0; layer < 3; layer++) {
                                const mistY = groundY + layer * H*0.04;
                                const mistGrad = ctx.createLinearGradient(0, mistY, 0, mistY + H*0.12);
                                const alpha = 0.3 - layer*0.1;
                                mistGrad.addColorStop(0, `rgba(15,8,30,0)`);
                                mistGrad.addColorStop(0.4, `rgba(15,8,30,${alpha})`);
                                mistGrad.addColorStop(1, `rgba(10,5,20,${alpha+0.3})`);
                                ctx.fillStyle = mistGrad;
                                ctx.fillRect(0, mistY, W, H*0.15);
                            }

                            // === 火把（城墙上多盏） ===
                            const torchPositions = [
                                { x: cx - castleW*0.38 }, { x: cx - castleW*0.16 },
                                { x: cx + castleW*0.2 },  { x: cx + castleW*0.38 },
                            ];
                            torchPositions.forEach(t => {
                                const tx = t.x, ty = wallY - H*0.03;
                                // 火把杆
                                ctx.fillStyle = '#100818';
                                ctx.fillRect(tx - 1, ty, 2, H*0.025);
                                // 光晕（大）
                                const glow = ctx.createRadialGradient(tx, ty - H*0.005, 0, tx, ty - H*0.005, castleW*0.1);
                                glow.addColorStop(0, 'rgba(255,160,30,0.3)');
                                glow.addColorStop(0.3, 'rgba(255,120,20,0.1)');
                                glow.addColorStop(0.7, 'rgba(200,80,10,0.02)');
                                glow.addColorStop(1, 'rgba(0,0,0,0)');
                                ctx.fillStyle = glow;
                                ctx.fillRect(tx - castleW*0.1, ty - H*0.06, castleW*0.2, castleW*0.2);
                                // 火焰核心
                                const flame = ctx.createRadialGradient(tx, ty - H*0.003, 0, tx, ty - H*0.003, castleW*0.015);
                                flame.addColorStop(0, 'rgba(255,200,60,0.8)');
                                flame.addColorStop(0.5, 'rgba(255,120,20,0.3)');
                                flame.addColorStop(1, 'rgba(0,0,0,0)');
                                ctx.fillStyle = flame;
                                ctx.fillRect(tx - castleW*0.015, ty - H*0.015, castleW*0.03, H*0.03);
                            });

                            // === 前景雾（最前层，盖在底部） ===
                            const fgMist = ctx.createLinearGradient(0, groundY - H*0.02, 0, H);
                            fgMist.addColorStop(0, 'rgba(10,5,20,0)');
                            fgMist.addColorStop(0.2, 'rgba(10,5,20,0.5)');
                            fgMist.addColorStop(1, 'rgba(5,2,12,0.95)');
                            ctx.fillStyle = fgMist;
                            ctx.fillRect(0, groundY - H*0.05, W, H - groundY + H*0.1);
                        }

        function refreshStartScreen() {
                    // 历史最佳
                    const brText = document.getElementById('br-text');
                    const best = getBestRecord();
                    if (best) {
                        const clsIcon = CONFIG.CLASSES[best.class] ? CONFIG.CLASSES[best.class].icon : '';
                        brText.innerHTML = `🏆 最佳: ${clsIcon} ${escHtml(best.name)} · 第<span class="br-score">${best.floor}</span>层 · <span class="br-score">${best.score}</span>分`;
                    } else {
                        brText.textContent = '🏆 暂无记录 · 开始你的第一次冒险吧';
                    }
                    // 继续游戏按钮
                    const contBtn = document.getElementById('continue-btn');
                    const contInfo = document.getElementById('cont-info');
                    if (hasSaveData()) {
                        const save = loadGame();
                        contBtn.style.display = 'block';
                        contInfo.textContent = `第 ${save.floor} 层 · ${save.playerName} · Lv.${save.player.level}`;
                    } else {
                        contBtn.style.display = 'none';
                    }
                                        // 音效按钮状态
                    const sfxBtn = document.getElementById('sfx-btn-start');
                    if (sfxBtn) {
                        sfxBtn.textContent = sfx.enabled ? '🔊 音效' : '🔇 静音';
                    }
                }

                function showKeyHelp() {
                            document.getElementById('keyhelp-modal').style.display = 'flex';
                            gameState.shopOpen = true;
                        }

                        function closeKeyHelp() {
                            document.getElementById('keyhelp-modal').style.display = 'none';
                            gameState.shopOpen = false;
                        }

                        function showEventEffect(good) {
                            const count = 14;
                            const chars = good
                                ? ['🎆','🎇','✨','🌟','💫','⭐','🎉']
                                : ['💀','☠️','🦴','👻','😈','💥','🖤'];
                            const color = good ? '#ffd700' : '#800';
                            for (let i = 0; i < count; i++) {
                                setTimeout(() => {
                                    const p = document.createElement('span');
                                    p.textContent = chars[Math.floor(Math.random() * chars.length)];
                                    p.style.cssText = `
                                        position:fixed; z-index:5000; pointer-events:none;
                                        left:${10 + Math.random() * 80}%;
                                        top:${10 + Math.random() * 70}%;
                                        font-size:${24 + Math.random() * 40}px;
                                        opacity:1;
                                        transition: all ${0.8 + Math.random() * 1.2}s ease-out;
                                    `;
                                    document.body.appendChild(p);
                                    requestAnimationFrame(() => {
                                        p.style.opacity = '0';
                                        p.style.transform = `translateY(${-60 - Math.random() * 100}px) rotate(${(Math.random()-0.5)*60}deg) scale(${0.5 + Math.random()})`;
                                    });
                                    setTimeout(() => p.remove(), 2500);
                                }, i * 60);
                            }
                            // 背景闪色
                            const flash = document.createElement('div');
                            flash.style.cssText = `
                                position:fixed;top:0;left:0;width:100%;height:100%;
                                z-index:4999;pointer-events:none;
                                background:${good ? 'rgba(255,215,0,' : 'rgba(180,0,0,'}0.25);
                                transition:opacity 0.8s ease-out;
                            `;
                            document.body.appendChild(flash);
                            requestAnimationFrame(() => { flash.style.opacity = '0'; });
                            setTimeout(() => flash.remove(), 1000);
                        }
