// ==================== 键盘控制 ====================
        document.addEventListener('keydown', (e) => {
            // 开场动画中：空格/回车/ESC 跳过
                        const introEl = document.getElementById('intro-animation');
                        if (introEl && introEl.classList.contains('active') && !introFinished) {
                if (e.key === ' ' || e.key === 'Enter' || e.key === 'Escape') {
                    e.preventDefault();
                    skipIntro();
                }
                return;
            }
            
            // 开始界面显示时：排行榜弹窗ESC关闭 / 回车开始游戏
                                    const startScr = document.getElementById('start-screen');
                                    if (startScr && startScr.style.display !== 'none' && startScr.style.display !== '') {
                            if (e.key === 'Escape') {
                                                            const lbModal = document.getElementById('leaderboard-modal');
                                                            if (lbModal && lbModal.style.display === 'flex') {
                                                                e.preventDefault();
                                                                closeLeaderboard();
                                                                return;
                                                            }
                                                            const wsModal = document.getElementById('workshop-modal');
                                                            if (wsModal && wsModal.style.display === 'flex') {
                                                                e.preventDefault();
                                                                closeWorkshop();
                                                                return;
                                                            }
                                                            const achPanel = document.getElementById('achieve-panel');
                                                            if (achPanel && achPanel.style.display === 'flex') {
                                                                e.preventDefault();
                                                                achPanel.style.display = 'none';
                                                                return;
                                                            }
                                                        }
                            if (e.key === 'Enter') {
                    e.preventDefault();
                    startGame();
                }
                return;
            }
            
// ESC 关闭商店/装备面板/角色面板/升级弹窗
            if (e.key === 'Escape') {
                if (gameState.shopOpen && gameState.currentNPC) {
                    closeShop();
                } else if (document.getElementById('levelup-modal').style.display === 'flex') {
                    // 升级弹窗不允许 ESC 关闭
                } else if (document.getElementById('char-sheet-modal').style.display === 'flex') {
                    closeCharSheet();
                } else if (document.getElementById('equip-detail-modal').style.display === 'flex') {
                                    closeEquipDetail();
                                } else if (document.getElementById('altar-modal').style.display === 'flex') {
                                    closeAltar();
                                } else if (document.getElementById('library-modal').style.display === 'flex') {
                                                                    closeLibrary();
                                                                } else if (document.getElementById('blacksmith-modal').style.display === 'flex') {
                                                                                                                                    closeBlacksmith();
                                                                                                                                } else if (document.getElementById('leaderboard-modal').style.display === 'flex') {
                                                                                                                                                                                                    closeLeaderboard();
                                                                                                                                                                                                } else if (document.getElementById('workshop-modal').style.display === 'flex') {
                                                                                                                                                                                                                                                                    closeWorkshop();
                                                                                                                                                                                                                                                                } else if (document.getElementById('achieve-panel').style.display === 'flex') {
                                                                                                                                                                                                                                                                                                                                    document.getElementById('achieve-panel').style.display = 'none';
                                                                                                                                                                                                                                                                                                                                } else if (document.getElementById('keyhelp-modal').style.display === 'flex') {
                                                                                                                                                                                                                                                                                                                                                    closeKeyHelp();
                                                                                                                                                                                                                                                                                                                                                } else if (document.getElementById('potion-pickup-modal').style.display === 'flex') {
                                                                                                                                                                                                                                                                                                                                                                    choosePotionAction('discard');
                                                                                                                                                                                                                                                                                                                                                                } else if (document.getElementById('well-modal').style.display === 'flex') {
                                                                                                                                                                                                                                                                                                                                                                    document.getElementById('well-modal').style.display = 'none';
                                                                                                                                                                                                                                                                                                                                                                    gameState.shopOpen = false;
                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                return;
            }
            
            // ` 键切换精灵/文字模式
            if (e.key === '`') {
                e.preventDefault();
                spriteMode = !spriteMode;
                renderMap();
                return;
            }
            
            // Tab 打开/关闭装备详情（必须在 shopOpen 守卫之前）
            if (e.key === 'Tab') {
                e.preventDefault();
                // 装备面板打开时→关闭；否则若不在商店中→打开
                if (document.getElementById('equip-detail-modal').style.display === 'flex') {
                    closeEquipDetail();
                } else if (!gameState.shopOpen || !gameState.currentNPC) {
                    toggleEquipDetail();
                }
                return;
                            }
            
                            // C 打开/关闭角色属性面板
                                                        if (e.key === 'c' || e.key === 'C') {
                                                                                        e.preventDefault();
                                                                                        if (document.getElementById('equip-detail-modal').style.display === 'flex') {
                                                                                            closeEquipDetail();
                                                                                        }
                                                                                        toggleCharSheet();
                                                                                                                    return;
                                                                                                                }
            
                                                                                                    // P 打开成就面板
                                                                                                                                                                                                        if (e.key === 'p' || e.key === 'P') {
                                                                                                        e.preventDefault();
                                                                                                        showAchievePanel();
                                                                                                        return;
                                                                                                    }
            
                            if (gameState.isGameOver) return;
            
                                        // 升级弹窗打开时不处理其他按键（除了C键关闭自己面板）
                                        if (document.getElementById('levelup-modal').style.display === 'flex') return;
            
                                                    // 装备对比弹窗打开时不处理按键
                                                                                                        if (document.getElementById('equip-compare-modal').style.display === 'flex') return;

                                                                                                        // 祭坛/图书馆弹窗打开时不处理按键
                                                                                                                                                            if (document.getElementById('altar-modal').style.display === 'flex') return;
                                                                                                                                                            if (document.getElementById('library-modal').style.display === 'flex') return;
                                                                                                                                                            if (document.getElementById('blacksmith-modal').style.display === 'flex') return;
            
                                                    // 商店打开时不处理其他按键
                                                                if (gameState.shopOpen) return;
            
                                                                // 调试键分发
                                                                if (handleDebugKey(e.key)) return;
            
                                                                // 药水背包快捷键
            if (['1','2','3','4'].includes(e.key)) {
                e.preventDefault();
                const slotIdx = parseInt(e.key) - 1;
                usePotionFromBelt(slotIdx);
                return;
            }

            switch (e.key) {
                case 'ArrowUp':
                case 'w':
                case 'W':
                    movePlayer(0, -1);
                    break;
                case 'ArrowDown':
                case 's':
                case 'S':
                    movePlayer(0, 1);
                    break;
                case 'ArrowLeft':
                case 'a':
                case 'A':
                    movePlayer(-1, 0);
                    break;
                case 'ArrowRight':
                case 'd':
                case 'D':
                    movePlayer(1, 0);
                    break;
case 'q':
case 'Q':
                    useActiveSkill();
                    break;
            }
        });

        // ==================== 调试键处理 (v3.29.1) ====================
        function handleDebugKey(key) {
            switch (key) {
                case '0':
                    gameState.godMode = !gameState.godMode;
                    addLog(gameState.godMode ? '🛡️ [0] 无敌模式开启' : '🛡️ [0] 无敌模式关闭', 'log-system');
                    updateStatusBar(); return true;
                case '5':
                    gameState.oneHitKill = !gameState.oneHitKill;
                    addLog(gameState.oneHitKill ? '💀 [5] 秒杀模式开启' : '💀 [5] 秒杀模式关闭', 'log-system');
                    return true;
                case '9':
                    gameState.floor = 5; addLog('⏩ [9] 跳转到第5层 Boss', 'log-system');
                    generateMap(); renderMap(); updateStatusBar(); return true;
                case '8':
                    gameState.floor = 3; addLog('⏩ [8] 跳转到第3层 商店', 'log-system');
                    generateMap(); renderMap(); updateStatusBar(); return true;
                case '7':
                    gameState.gold += 500; addLog('💰 [7] +500金币', 'log-system');
                    updateStatusBar(); return true;
                case '6':
                    gameState.player.hp = gameState.player.maxHp + sumEquipHp();
                    addLog('❤️ [6] HP已回满', 'log-system');
                    updateStatusBar(); return true;
                case ' ':
                    gameState.floor += 1; addLog('⏩ [空格] 跳转到第' + gameState.floor + '层', 'log-system');
                    generateMap(); renderMap(); updateStatusBar(); return true;
            }
            return false;
        }
